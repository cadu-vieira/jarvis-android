# JARVIS Android — Etapa 3

Etapa 3 final com TTS dinâmico Kokoro/Sherpa-ONNX.

- Voz: `bm_george`
- Kokoro v1.0: SID 26
- Modelo baixado pelo GitHub Actions
- A interface não usa mais `android.speech.tts.TextToSpeech`
- A fala da interface e do serviço passa pelo mesmo motor Kokoro

O workflow baixa o pacote oficial `kokoro-int8-multi-lang-v1_0` e o AAR oficial do Sherpa-ONNX antes de compilar.
